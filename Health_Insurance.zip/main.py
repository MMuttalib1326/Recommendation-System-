from fastapi import FastAPI
import tensorflow as tf
import numpy as np
from sentence_transformers import SentenceTransformer
from pydantic import BaseModel
import json

app = FastAPI()

model = SentenceTransformer("hkunlp/instructor-large")

policy_texts = [
    '{"Policy": "X", "Premium": 0.6, "Waiting_Period": 0, "Coverage": "Maternity, dental, optical", "Insurer_Rating": 0.9}',
    '{"Policy": "Y", "Premium": 0.675, "Waiting_Period": 30, "Coverage": "Maternity, neonatal care, hospital", "Insurer_Rating": 0.84}',
    '{"Policy": "Z", "Premium": 0.55, "Waiting_Period": 0, "Coverage": "Maternity, partnered with Royal Women’s Hospital", "Insurer_Rating": 0.94}'
]

policy_embeddings = model.encode(policy_texts)
policy_embeddings = tf.convert_to_tensor(policy_embeddings, dtype=tf.float32)

class UserProfile(BaseModel):
    Age: int
    Location: str
    Health_Needs: str
    Budget: float
    Customer_Satisfaction_Preference: str
    k:int

@app.post("/recommendations/")
def rank_policies(user_profile: UserProfile):
    
    user_text = str(user_profile.model_dump())
    k = user_profile.model_dump()["k"]

    user_embedding = model.encode(user_text)
    user_embedding = tf.convert_to_tensor(user_embedding, dtype=tf.float32)
    user_embedding = tf.reshape(user_embedding, (1, -1))  # Reshape for matrix multiplication

    scores = tf.matmul(user_embedding, policy_embeddings, transpose_b=True)
    scores = scores.numpy().flatten()

    ranked_policies = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)

    top_k_policies = [{"rank": i+1, "policy": json.loads(policy_texts[idx]), "score": float(score)}
                      for i, (idx, score) in enumerate(ranked_policies[:k])]

    output =  {"top_"+str(k)+"_policies": top_k_policies}
    return output